# Layout

Present the responsive site design to the following widths:

-720p 16:9 desktop (1280 x 720)
-800p 16:10 desktop (1280 x 800)
-1080p 16:9 desktop (1920 x 1080)
-1200p 16:10 desktop (1920 x 1200)

# Colors

- Red: hsl(0, 78%, 62%)
- Cyan: hsl(180, 62%, 55%)
- Orange: hsl(34, 97%, 64%)
- Blue: hsl(212, 86%, 64%)

- Very Dark Blue: hsl(234, 12%, 34%)
- Grayish Blue: hsl(229, 6%, 66%)
- Very Light Gray: hsl(0, 0%, 98%)

# Typography

body
- Family: [Poppins](https://fonts.google.com/specimen/Poppins)
- Weights: 200, 400, 600
- Font size: 15px
