# Layout

Present the responsive site design to the following widths:

-720p 16:9 desktop (1280 x 720)
-800p 16:10 desktop (1280 x 800)
-1080p 16:9 desktop (1920 x 1080)
-1200p 16:10 desktop (1920 x 1200)

# Colors

Violet: rgba(103,75,175,255);
Soft Magenta: rgba(232,130,232,255);

# Typography

headings
- Family: [Poppins](https://fonts.google.com/specimen/Poppins)
- Weights: 400, 600

body
- Family: [Open Sans](https://fonts.google.com/specimen/Open+Sans)
- Weights: 400

# Icons

https://icons.getbootstrap.com/