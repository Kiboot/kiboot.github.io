# Layout

Present the responsive site design to the following widths:

-720p 16:9 desktop (1280 x 720)
-800p 16:10 desktop (1280 x 800)
-1080p 16:9 desktop (1920 x 1080)
-1200p 16:10 desktop (1920 x 1200)

# Colors
### Primary

- Yellow: hsl(47, 88%, 63%)

### Neutral

- White: hsl(0, 0%, 100%)
- Grey: hsl(0, 0%, 50%)
- Black: hsl(0, 0%, 7%)

# Typography

body
- Family: [Figtree](https://fonts.google.com/specimen/Figtree)
- Weights: 600, 800
- Font size (paragraph): 16px