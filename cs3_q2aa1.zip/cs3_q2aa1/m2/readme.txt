BG: rgba(10,12,27,255)
Card: rgba(28,25,56,255)
Highlight text: rgba(28,25,56,255)
