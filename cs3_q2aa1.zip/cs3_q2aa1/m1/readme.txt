BG: rgba(10,57,128,255)
Card: rgba(13,71,161,255)
Button: rgba(255,202,40,255)
