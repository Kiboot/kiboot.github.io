# Layout

Present the responsive site design to the following widths:

-720p 16:9 desktop (1280 x 720)
-800p 16:10 desktop (1280 x 800)
-1080p 16:9 desktop (1920 x 1080)
-1200p 16:10 desktop (1920 x 1200)

# Colors

### Primary

- Soft blue: hsl(215, 51%, 70%)
- Cyan: hsl(178, 100%, 50%)

### Neutral

- Very dark blue (main BG): hsl(217, 54%, 11%)
- Very dark blue (card BG): hsl(216, 50%, 16%)
- Very dark blue (line): hsl(215, 32%, 27%)
- White: hsl(0, 0%, 100%)


# Typography


body
- Family: [Outfit](https://fonts.google.com/specimen/Outfit)
- Weights: 300, 400, 600
- Font size (paragraph): 18px

