# Layout

Present the responsive site design to the following widths:

-720p 16:9 desktop (1280 x 720)
-800p 16:10 desktop (1280 x 800)
-1080p 16:9 desktop (1920 x 1080)
-1200p 16:10 desktop (1920 x 1200)

# Colors

### Primary

Bright orange: hsl(31, 77%, 52%)
Dark cyan: hsl(184, 100%, 22%)
Very dark cyan: hsl(179, 100%, 13%)

### Neutral

Transparent white (paragraphs): hsla(0, 0%, 100%, 0.75)
Very light gray (background, headings, buttons): hsl(0, 0%, 95%)

# Typography

body
- Family: [Lexend Deca](https://fonts.google.com/specimen/Lexend+Deca)
- Weights: 400

- Family: [Big Shoulders Display](https://fonts.google.com/specimen/Big+Shoulders+Display)
- Weights: 700
- Font size: 15px

